﻿import ctypes
from ctypes import wintypes
from pathlib import Path
import time
from PIL import ImageGrab
u=ctypes.windll.user32
hwnd=u.FindWindowW(None,'PDF Translate')
if not hwnd: raise SystemExit('Electron window not found')
print('hwnd',hwnd,'visible',u.IsWindowVisible(hwnd),'iconic',u.IsIconic(hwnd))
u.ShowWindow(hwnd,9)
u.SetWindowPos(hwnd,-1,0,0,0,0,0x0001|0x0002|0x0040)
u.BringWindowToTop(hwnd)
u.SetForegroundWindow(hwnd)
time.sleep(2)
r=wintypes.RECT();u.GetWindowRect(hwnd,ctypes.byref(r))
out=Path('output/presentation-demo-2026-10-01/electron-screenshot-check.png')
if out.exists(): raise SystemExit('Refusing overwrite')
ImageGrab.grab(bbox=(r.left,r.top,r.right,r.bottom),all_screens=True).save(out)
print(out.resolve(),(r.left,r.top,r.right,r.bottom),'foreground',u.GetForegroundWindow())

