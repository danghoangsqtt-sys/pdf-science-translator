﻿from pathlib import Path
import fitz

out = Path('output/presentation-demo-2026-10-01')
out.mkdir(parents=True, exist_ok=True)
path = out / 'math-physics-final-demo.pdf'
if path.exists():
    raise SystemExit(f'Refusing to overwrite {path}')
doc = fitz.open()
p = doc.new_page(width=595, height=842)
navy = (0.08, 0.19, 0.29)
blue = (0.09, 0.42, 0.58)
muted = (0.32, 0.37, 0.42)
p.draw_rect(fitz.Rect(0, 0, 595, 85), color=navy, fill=navy)
p.insert_text((42, 44), 'MATHEMATICS AND PHYSICS', fontsize=19, fontname='helv', color=(1,1,1))
p.insert_text((42, 67), 'A short English handout for translation testing', fontsize=10, color=(0.85,0.9,0.93))
def heading(y, title):
    p.insert_text((42, y), title, fontsize=15, fontname='hebo', color=blue)
def paragraph(y, value):
    result = p.insert_textbox(fitz.Rect(42,y,553,y+80), value, fontsize=11, fontname='helv', lineheight=1.35, color=navy)
    if result < 0: raise ValueError(value)
heading(121, '1. Mathematics: the derivative')
paragraph(137, 'The derivative measures how quickly a quantity changes. If the position of an object is x(t), its instantaneous velocity is the derivative of position with respect to time. The slope of a tangent line provides a geometric interpretation.')
p.insert_text((73, 241), 'x(t) = x0 + v0*t + (1/2)*a*t^2', fontsize=13, fontname='cour', color=navy)
p.insert_text((73, 264), 'v(t) = dx/dt = v0 + a*t', fontsize=13, fontname='cour', color=navy)
heading(337, '2. Physics: Newtonian motion')
paragraph(353, 'Newton\'s second law connects the net force acting on an object to its mass and acceleration. For a constant mass, doubling the force doubles the acceleration. The equation helps engineers predict motion and design safe systems.')
p.insert_text((73, 456), 'F = m*a', fontsize=15, fontname='cour', color=navy)
p.insert_text((42, 489), 'A 5 kg cart under a net force of 10 N accelerates at 2 m/s^2.', fontsize=11, color=navy)
heading(533, '3. Energy and practical use')
paragraph(549, 'Kinetic energy depends on mass and the square of speed. A vehicle moving twice as fast has four times the kinetic energy. This relationship is useful when estimating braking distance and explaining laboratory measurements.')
p.insert_text((73, 651), 'E_k = (1/2)*m*v^2', fontsize=15, fontname='cour', color=navy)
p.draw_line((42,701),(553,701), color=(0.78,0.83,0.85))
p.insert_text((42,726), 'Key quantities', fontsize=10, fontname='hebo', color=muted)
p.insert_text((42,748), 'mass: kg     force: N     acceleration: m/s^2     energy: J', fontsize=10, fontname='cour', color=navy)
p.insert_text((42,807), 'Demo document created for PDF Translate presentation | 1 page', fontsize=9, color=muted)
doc.set_metadata({'title':'Mathematics and Physics - English demo','author':'Presentation test'})
doc.save(path)
print(path.resolve())

