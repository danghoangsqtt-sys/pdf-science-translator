﻿import ctypes
from ctypes import wintypes
from pathlib import Path
import time
from PIL import ImageGrab
u=ctypes.windll.user32
k=ctypes.windll.kernel32
k.GlobalAlloc.argtypes=[ctypes.c_uint,ctypes.c_size_t]
k.GlobalAlloc.restype=ctypes.c_void_p
k.GlobalLock.argtypes=[ctypes.c_void_p]
k.GlobalLock.restype=ctypes.c_void_p
k.GlobalUnlock.argtypes=[ctypes.c_void_p]
u.SetClipboardData.argtypes=[ctypes.c_uint,ctypes.c_void_p]
u.SetClipboardData.restype=ctypes.c_void_p
hwnd=u.FindWindowW(None,'PDF Translate')
if not hwnd: raise SystemExit('Electron window not found')
def title():
    h=u.GetForegroundWindow();b=ctypes.create_unicode_buffer(256);u.GetWindowTextW(h,b,256);return h,b.value
r=wintypes.RECT();u.GetWindowRect(hwnd,ctypes.byref(r))
dialog=u.FindWindowW(None,'Open')
if dialog:
    u.SetWindowPos(dialog,-1,0,0,0,0,0x0001|0x0002|0x0040)
    u.SetForegroundWindow(dialog)
else:
    u.SetWindowPos(hwnd,-1,0,0,0,0,0x0001|0x0002|0x0040)
    u.SetForegroundWindow(hwnd)
    time.sleep(.5)
    u.SetCursorPos(r.left+95,r.top+150)
    u.mouse_event(2,0,0,0,0);u.mouse_event(4,0,0,0,0)
    time.sleep(1.3)
print('dialog',title())
dialog=u.FindWindowW(None,'Open')
if not dialog: raise SystemExit('Open dialog did not appear')
dr=wintypes.RECT();u.GetWindowRect(dialog,ctypes.byref(dr))
u.SetWindowPos(dialog,-1,0,0,0,0,0x0001|0x0002|0x0040)
u.SetForegroundWindow(dialog)
u.SetCursorPos(dr.left+350,dr.bottom-63)
u.mouse_event(2,0,0,0,0);u.mouse_event(4,0,0,0,0)
time.sleep(.3)
value=str(Path('output/presentation-demo-2026-10-01/math-physics-final-demo.pdf').resolve())
GMEM_MOVEABLE=0x0002
CF_UNICODETEXT=13
handle=k.GlobalAlloc(GMEM_MOVEABLE,(len(value)+1)*2)
ptr=k.GlobalLock(handle)
ctypes.memmove(ptr,ctypes.create_unicode_buffer(value),(len(value)+1)*2)
k.GlobalUnlock(ctypes.c_void_p(handle))
u.OpenClipboard(0);u.EmptyClipboard();u.SetClipboardData(CF_UNICODETEXT,ctypes.c_void_p(handle));u.CloseClipboard()
u.keybd_event(0x11,0,0,0);u.keybd_event(0x56,0,0,0);u.keybd_event(0x56,0,2,0);u.keybd_event(0x11,0,2,0)
time.sleep(.2)
u.keybd_event(0x0D,0,0,0);u.keybd_event(0x0D,0,2,0)
time.sleep(4)
print('after',title())
u.SetForegroundWindow(hwnd)
time.sleep(.5)
out=Path('output/presentation-demo-2026-10-01/electron-screenshot-source-preview-v2.png')
if out.exists(): raise SystemExit('Refusing overwrite')
ImageGrab.grab(bbox=(r.left,r.top,r.right,r.bottom),all_screens=True).save(out)
print(out.resolve())

