﻿from pathlib import Path
import subprocess,time,json
b=Path('output/electron-science-benchmark-2026-10-01')
python=Path('.venv/Scripts/python.exe').resolve();runner=Path('scripts/translate_pdf.py').resolve()
for slug in ['short-quantum-position-momentum','long-pinn-error-certification']:
    out=b/f'{slug}-p1-segments.jsonl'
    if out.exists():raise SystemExit('Refusing overwrite')
    t=time.perf_counter();p=subprocess.run([str(python),str(runner),str(b/f'{slug}.pdf'),'--engine','handoff','--emit-segments',str(out),'--pages','1','--source-language','en','--target-language','vi','--threads','2'],capture_output=True,text=True,encoding='utf-8',errors='replace');print(slug,'seconds',round(time.perf_counter()-t,3),'count',len(out.read_text(encoding='utf-8').splitlines()),'returncode',p.returncode)
