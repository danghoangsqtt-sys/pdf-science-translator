﻿from pathlib import Path
from PIL import Image, ImageChops
import fitz,json,re
b=Path('output/electron-science-benchmark-2026-10-01')
items=[('short-quantum-position-momentum',2,[(285,875,860,1020)]),('medium-neutron-stars',9,[(185,125,785,375),(185,485,785,725)]),('long-pinn-error-certification',4,[(85,100,812,470)])]
results=[]
for slug,page,rectangles in items:
    source=b/f'{slug}.pdf';target=b/f'{slug}-vi.pdf'
    with fitz.open(source) as original,fitz.open(target) as translated:
        page_count=original.page_count
        same_pages=original.page_count==translated.page_count
        same_canvas=all(a.rect==c.rect for a,c in zip(original,translated))
        text=translated[page-1].get_text()
        bad_markers=re.findall(r'\{v\d+\}|</?[bst]\d+>|\u0000|\ufffd',text)
        outside=[]
        for block in translated[page-1].get_text('dict')['blocks']:
            if 'lines' not in block:continue
            for line in block['lines']:
                for span in line['spans']:
                    if not translated[page-1].rect.contains(fitz.Rect(span['bbox'])):outside.append(span['text'])
    src_image=Image.open(b/f'{slug}-source-p{page}.png').convert('RGB')
    dst_image=Image.open(b/f'{slug}-translated-p{page}.png').convert('RGB')
    pixels_equal=0;pixels_total=0
    for rect in rectangles:
        a=src_image.crop(rect);c=dst_image.crop(rect)
        diff=ImageChops.difference(a,c)
        pixels_total+=a.width*a.height
        pixels_equal+=sum(1 for v in diff.get_flattened_data() if v==(0,0,0))
    coverage=json.loads((b/'sample-rebuild-times.json').read_text(encoding='utf-8'))
    sample=next(x for x in coverage if x['paper']==slug)
    result={'paper':slug,'sample_page':page,'pages':page_count,'same_pages':same_pages,'same_canvas':same_canvas,'figure_pixel_match_pct':round(pixels_equal/pixels_total*100,3),'figures_checked':len(rectangles),'translated_segments':sample['supplied_segments'],'sample_segments':sample['total_segments'],'translation_coverage_pct':round(sample['supplied_segments']/sample['total_segments']*100,1),'bad_markers':bad_markers,'outside_spans':outside[:8]}
    results.append(result);print(json.dumps(result,ensure_ascii=False))
out=b/'qa-metrics.json'
if out.exists():raise SystemExit('Refusing overwrite')
out.write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf-8')
