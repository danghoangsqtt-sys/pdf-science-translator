﻿import json,re,subprocess,time
from pathlib import Path
b=Path('output/electron-science-benchmark-2026-10-01')
items=[
('short-quantum-position-momentum',2,{11:'HÌNH 1. Sơ đồ minh họa bất đẳng thức lan truyền. Đường màu xanh biểu diễn trạng thái lượng tử. Hạt chuyển động dọc theo trục<s2> </s2><b62></b62>. <b63></b63> biểu thị <t0></t0> theo phương ngang của photon. Đường chấm đỏ biểu diễn ranh giới quỹ đạo, nơi photon từ khoảng vị trí ban đầu<s2> </s2><b64></b64> và khoảng <t1></t1><s2> </s2><b65></b65> đi qua khoảng<s2> </s2><b66></b66>.'}),
('medium-neutron-stars',9,{
1:'. Quan hệ khối lượng-bán kính cho EOS SLy4 (khung trái) và APR4 (khung phải). Các kiểu nét và màu đường khác nhau tương ứng với các giá trị khác nhau của tham số <b3></b3>. Các giới hạn quan sát hiện tại được thể hiện bằng vùng tô bóng.',
2:'. Quan hệ khối lượng-bán kính cho EOS FPS (khung trái) và L (khung phải). Các kiểu nét và màu đường khác nhau tương ứng với các giá trị khác nhau của tham số <b8></b8>. Các giới hạn quan sát hiện tại được thể hiện bằng vùng tô bóng.',
3:'Điều đáng quan tâm là xem khối lượng cực đại thay đổi thế nào khi thay đổi tham số <b9></b9> và so sánh với phương pháp nhiễu loạn trong [9]. Ở Hình 3, chúng tôi vẽ khối lượng cực đại <b10></b10> theo <b11></b11> cho EOS SLy4 và APR4. Trường hợp thuyết tương đối rộng được biểu diễn bằng <b12></b12> 0. Xu hướng này đặc trưng cho mọi EOS khảo sát. Khi <b13></b13> 0, khối lượng cực đại tiến tới giá trị tương ứng trong thuyết tương đối rộng đối với từng EOS. Khi <b14></b14> tăng, <b15></b15> ban đầu giảm, đạt cực tiểu rồi tăng đơn điệu. Giá trị cực đại của <b16></b16> đạt tại <b17></b17> và lớn hơn lý thuyết Einstein thuần túy khoảng 10%, tùy EOS. Giá trị cực tiểu thường xuất hiện tại <b18></b18> 1; <b19></b19> sai khác dưới 1% so với thuyết tương đối rộng thuần túy. Với các phương trình trạng thái thực tế được xét, bán kính <b20></b20> của các mô hình có khối lượng cực đại tăng đơn điệu theo <b21></b21>.',
}),
('long-pinn-error-certification',4,{
1:'Hình 1: Chặn các đạo hàm riêng bằng<s2> </s2><b1></b1>-CROWN: phương pháp kết hợp của chúng tôi để chặn<s2> </s2><b2></b2> và<s2> </s2><b3></b3> dùng lan truyền ngược và thay thế thuận (theo Shi và cộng sự, 2020) để tính các chặn với độ phức tạp<s2> </s2><b4></b4>(<b5></b5>) thay cho độ phức tạp<s2> </s2><b6></b6>(<b7></b7>) của lan truyền ngược hoàn toàn như Xu và cộng sự (2020).',
3:'4.1. Chặn các đạo hàm riêng của<s2> </s2><b16></b16>',
11:'Từ kết quả này, ta có thể chặn dưới và chặn trên một cách hiệu quả bằng hàm tuyến tính cho<s2> </s2><b51></b51>.',
}),
]
python=Path('.venv/Scripts/python.exe').resolve(); runner=Path('scripts/translate_pdf.py').resolve()
results=[]
for slug,page,mapping in items:
    src=b/f'{slug}.pdf'; segment_path=b/f'{slug}-p{page}-segments.jsonl'
    sources=[json.loads(x)['src'] for x in segment_path.read_text(encoding='utf-8').splitlines()]
    translations=b/f'{slug}-p{page}-translations.jsonl'
    missing=b/f'{slug}-p{page}-still-missing.jsonl'
    if translations.exists() or missing.exists() or (b/f'{slug}-vi.pdf').exists():raise SystemExit(f'Refusing overwrite for {slug}')
    rows=[]
    for index,dst in mapping.items():
        source=sources[index-1]
        pattern=r'</?[bst]\d+>'
        assert re.findall(pattern,source)==re.findall(pattern,dst),(slug,index)
        rows.append({'src':source,'dst':dst})
    translations.write_text(''.join(json.dumps(row,ensure_ascii=False)+'\n' for row in rows),encoding='utf-8')
    cmd=[str(python),str(runner),str(src),'--engine','handoff','--segments',str(translations),'--emit-segments',str(missing),'--output-dir',str(b),'--pages',str(page),'--source-language','en','--target-language','vi','--domain','natural_sciences','--threads','2']
    start=time.perf_counter();proc=subprocess.run(cmd,capture_output=True,text=True,encoding='utf-8',errors='replace');elapsed=time.perf_counter()-start
    result={'paper':slug,'page':page,'supplied_segments':len(rows),'total_segments':len(sources),'rebuild_seconds':round(elapsed,3),'still_missing':len(missing.read_text(encoding='utf-8').splitlines()) if missing.exists() else None,'returncode':proc.returncode,'stdout':proc.stdout[-300:],'stderr_tail':proc.stderr[-350:]}
    print(json.dumps(result,ensure_ascii=False),flush=True);results.append(result)
    if proc.returncode:break
out=b/'sample-rebuild-times.json'
if out.exists():raise SystemExit(f'Refusing overwrite {out}')
out.write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf-8')
