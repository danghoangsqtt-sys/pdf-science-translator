﻿from pathlib import Path
import hashlib
import json
import re
import fitz

base=Path('output/presentation-demo-2026-10-01')
source=base/'math-physics-english.pdf'
target=base/'math-physics-english-vi.pdf'
report={}
for label,path in [('source',source),('translated',target)]:
    doc=fitz.open(path)
    pages=[]
    for index,page in enumerate(doc):
        png=base/f'{label}-page-{index+1}.png'
        if not png.exists():
            page.get_pixmap(matrix=fitz.Matrix(2,2), alpha=False).save(png)
        text=page.get_text()
        blocks=page.get_text('dict')['blocks']
        outside=[]
        for block in blocks:
            if block.get('type') != 0: continue
            for line in block.get('lines',[]):
                for span in line.get('spans',[]):
                    x0,y0,x1,y1=span['bbox']
                    if x0 < -0.5 or y0 < -0.5 or x1 > page.rect.width+0.5 or y1 > page.rect.height+0.5:
                        outside.append({'text':span['text'],'bbox':span['bbox']})
        pages.append({'size':[page.rect.width,page.rect.height],'chars':len(text),'text':text,'outside_spans':outside,'markers':re.findall(r'\{v\d+\}|<[/]?[bs]\d+>|\ufffd|\x00',text)})
    report[label]={'path':str(path.resolve()),'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'pages':pages}
print(json.dumps(report,ensure_ascii=False,indent=2))

