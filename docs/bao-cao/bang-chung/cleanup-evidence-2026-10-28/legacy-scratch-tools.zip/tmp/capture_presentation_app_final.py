﻿from pathlib import Path
import time
import customtkinter as ctk
from PIL import ImageGrab
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from app.gui import App, PRIMARY_COLOR, PRIMARY_COLOR_HOVER, use_bundled_assets

use_bundled_assets()
ctk.set_appearance_mode('system')
ctk.set_default_color_theme('blue')
ctk.ThemeManager.theme['CTkButton']['fg_color'] = [PRIMARY_COLOR, PRIMARY_COLOR]
ctk.ThemeManager.theme['CTkButton']['hover_color'] = [PRIMARY_COLOR_HOVER, PRIMARY_COLOR_HOVER]
app = App()
app._add([Path('output/presentation-demo-2026-10-01/math-physics-final-demo.pdf').resolve()])
app.update()
time.sleep(1)
app.update()
x, y = app.winfo_rootx(), app.winfo_rooty()
w, h = app.winfo_width(), app.winfo_height()
out = Path('output/presentation-demo-2026-10-01/app-screenshot-final.png')
if out.exists(): raise SystemExit(f'Refusing to overwrite {out}')
ImageGrab.grab(bbox=(x,y,x+w,y+h), all_screens=True).save(out)
print(f'{out.resolve()} {w}x{h}')
app.destroy()


