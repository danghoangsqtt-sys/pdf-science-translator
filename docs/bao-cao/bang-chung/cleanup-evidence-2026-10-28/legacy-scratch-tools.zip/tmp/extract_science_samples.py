﻿from pathlib import Path
import subprocess,time,json
b=Path('output/electron-science-benchmark-2026-10-01')
python=Path('.venv/Scripts/python.exe').resolve()
runner=Path('scripts/translate_pdf.py').resolve()
items=[('short-quantum-position-momentum',2),('medium-neutron-stars',9),('long-pinn-error-certification',4)]
results=[]
for slug,page in items:
    path=b/f'{slug}-p{page}-segments.jsonl'
    if path.exists(): raise SystemExit(f'Refusing overwrite {path}')
    cmd=[str(python),str(runner),str(b/f'{slug}.pdf'),'--engine','handoff','--emit-segments',str(path),'--pages',str(page),'--source-language','en','--target-language','vi','--domain','natural_sciences','--threads','2']
    t=time.perf_counter(); p=subprocess.run(cmd,capture_output=True,text=True,encoding='utf-8',errors='replace'); elapsed=time.perf_counter()-t
    result={'paper':slug,'page':page,'extraction_seconds':round(elapsed,3),'segments':len(path.read_text(encoding='utf-8').splitlines()) if path.exists() else None,'returncode':p.returncode,'stderr_tail':p.stderr[-250:]}
    print(json.dumps(result,ensure_ascii=False),flush=True);results.append(result)
    if p.returncode:break
path=b/'sample-extraction-times.json'
if path.exists():raise SystemExit(f'Refusing overwrite {path}')
path.write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf-8')
