﻿import ctypes
from ctypes import wintypes
from pathlib import Path
import time
from PIL import ImageGrab

user32=ctypes.windll.user32
hwnd=user32.FindWindowW(None,'PDF Translate')
if not hwnd: raise SystemExit('Electron window not found')
user32.ShowWindow(hwnd,9)
user32.SetForegroundWindow(hwnd)
time.sleep(1.5)
rect=wintypes.RECT()
user32.GetWindowRect(hwnd,ctypes.byref(rect))
out=Path('output/presentation-demo-2026-10-01/electron-screenshot-empty.png')
if out.exists(): raise SystemExit('Refusing overwrite')
ImageGrab.grab(bbox=(rect.left,rect.top,rect.right,rect.bottom),all_screens=True).save(out)
print(out.resolve(),(rect.left,rect.top,rect.right,rect.bottom))
