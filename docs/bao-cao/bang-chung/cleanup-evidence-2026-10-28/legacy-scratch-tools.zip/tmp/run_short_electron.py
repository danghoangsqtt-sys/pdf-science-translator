﻿import ctypes,time
from ctypes import wintypes
from pathlib import Path
from PIL import ImageGrab
u=ctypes.windll.user32
h=u.FindWindowW(None,'PDF Translate')
if not h:raise SystemExit('Electron window missing')
u.ShowWindow(h,9);u.SetWindowPos(h,-1,0,0,0,0,0x0001|0x0002|0x0040);u.SetForegroundWindow(h)
time.sleep(.3)
r=wintypes.RECT();u.GetWindowRect(h,ctypes.byref(r))
u.SetCursorPos(r.left+750,r.top+200)
u.mouse_event(2,0,0,0,0);u.mouse_event(4,0,0,0,0)
t=time.perf_counter();print('clicked',time.strftime('%Y-%m-%d %H:%M:%S'),flush=True)
base=Path('output/electron-science-benchmark-2026-10-01')
for delay,label in [(2,'running'),(30,'after-32s')]:
    time.sleep(delay)
    out=base/f'electron-short-{label}.png'
    if out.exists():raise SystemExit(f'Refusing overwrite {out}')
    u.ShowWindow(h,9);u.SetWindowPos(h,-1,0,0,0,0,0x0001|0x0002|0x0040);u.SetForegroundWindow(h)
    time.sleep(.3)
    ImageGrab.grab(bbox=(r.left,r.top,r.right,r.bottom),all_screens=True).save(out)
    print(label,round(time.perf_counter()-t,2),out.resolve(),flush=True)
