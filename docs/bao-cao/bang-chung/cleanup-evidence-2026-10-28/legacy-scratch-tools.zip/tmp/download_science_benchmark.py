﻿from pathlib import Path
from urllib.request import Request, urlopen
import hashlib
import fitz
base=Path('output/electron-science-benchmark-2026-10-01')
base.mkdir(parents=True,exist_ok=True)
papers=[('short-quantum-position-momentum','2207.07270'),('medium-neutron-stars','1402.4469'),('long-pinn-error-certification','2305.10157')]
for slug,identifier in papers:
    path=base/f'{slug}.pdf'
    if path.exists():
        print('EXISTS',path)
        continue
    url=f'https://arxiv.org/pdf/{identifier}'
    request=Request(url,headers={'User-Agent':'Mozilla/5.0 (research benchmark)'})
    with urlopen(request,timeout=90) as response:
        data=response.read()
    if not data.startswith(b'%PDF-'): raise RuntimeError(f'Unexpected response for {url}: {data[:80]!r}')
    path.write_bytes(data)
    with fitz.open(path) as doc:
        print(slug,'pages',doc.page_count,'bytes',len(data),'sha256',hashlib.sha256(data).hexdigest())
