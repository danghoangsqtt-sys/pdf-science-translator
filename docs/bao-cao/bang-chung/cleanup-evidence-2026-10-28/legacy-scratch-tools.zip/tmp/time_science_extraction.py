﻿from pathlib import Path
import subprocess,time,json,sys
base=Path('output/electron-science-benchmark-2026-10-01')
python=Path('.venv/Scripts/python.exe').resolve()
runner=Path('scripts/translate_pdf.py').resolve()
papers=['short-quantum-position-momentum','medium-neutron-stars','long-pinn-error-certification']
results=[]
for slug in papers:
    src=base/f'{slug}.pdf'
    segments=base/f'{slug}-all-segments.jsonl'
    if segments.exists():raise SystemExit(f'Refusing overwrite {segments}')
    cmd=[str(python),str(runner),str(src),'--engine','handoff','--emit-segments',str(segments),'--source-language','en','--target-language','vi','--domain','natural_sciences','--threads','2']
    started=time.perf_counter()
    proc=subprocess.run(cmd,text=True,capture_output=True,encoding='utf-8',errors='replace')
    elapsed=time.perf_counter()-started
    count=len(segments.read_text(encoding='utf-8').splitlines()) if segments.exists() else 0
    result={'paper':slug,'seconds':round(elapsed,3),'segments':count,'returncode':proc.returncode,'stdout':proc.stdout.strip(),'stderr_tail':proc.stderr[-500:]}
    results.append(result)
    print(json.dumps(result,ensure_ascii=False),flush=True)
    if proc.returncode:break
out=base/'extraction-times.json'
if out.exists():raise SystemExit(f'Refusing overwrite {out}')
out.write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf-8')
