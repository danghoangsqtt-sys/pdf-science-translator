﻿from pathlib import Path
import json
import numpy as np
from PIL import Image
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager

base=Path('output/electron-science-benchmark-2026-10-01')
font=Path('app/fonts/BeVietnamPro-Regular.ttf').resolve()
font_manager.fontManager.addfont(str(font))
plt.rcParams['font.family']=font_manager.FontProperties(fname=str(font)).get_name()
plt.rcParams['font.size']=11
plt.rcParams['axes.spines.top']=False
plt.rcParams['axes.spines.right']=False
labels=['Ngắn','Trung bình','Dài']
slugs=['short-quantum-position-momentum','medium-neutron-stars','long-pinn-error-certification']
pages=[6,14,30]
full=json.loads((base/'extraction-times.json').read_text(encoding='utf-8'))
rebuild=json.loads((base/'sample-rebuild-times.json').read_text(encoding='utf-8'))
full_times=[next(row['seconds'] for row in full if row['paper']==slug) for slug in slugs]
sample_times=[next(row['rebuild_seconds'] for row in rebuild if row['paper']==slug) for slug in slugs]
coverage=[next(row['supplied_segments']/row['total_segments']*100 for row in rebuild if row['paper']==slug) for slug in slugs]
fig_regions={
slugs[0]:(2,[(285,875,860,1020)]),
slugs[1]:(9,[(185,125,785,375),(185,485,785,725)]),
slugs[2]:(4,[(85,100,812,470)]),
}
ink_match=[]
for slug in slugs:
    page,rects=fig_regions[slug]
    source=Image.open(base/f'{slug}-source-p{page}.png').convert('RGB')
    target=Image.open(base/f'{slug}-translated-p{page}.png').convert('RGB')
    equal=0;total=0
    for rect in rects:
        a=np.asarray(source.crop(rect));b=np.asarray(target.crop(rect))
        ink=np.any(a<245,axis=2)
        total+=int(ink.sum())
        equal+=int((np.all(a==b,axis=2)&ink).sum())
    ink_match.append(equal/total*100)

fig,ax=plt.subplots(figsize=(9.2,5.0))
fig.patch.set_facecolor('white')
ax.plot(pages,full_times,color='#14452F',linewidth=2.5,marker='o',markersize=10)
for x,y in zip(pages,full_times):ax.annotate(f'{y:.2f} giây',(x,y),xytext=(0,10),textcoords='offset points',ha='center',fontweight='bold')
ax.set_xticks(pages,[f'{label}: {page} trang' for label,page in zip(labels,pages)])
ax.set_ylim(0,22);ax.set_ylabel('Thời gian (giây)')
ax.set_title('Thời gian phân tích PDF theo độ dài bài báo',fontsize=15,fontweight='bold',pad=16)
ax.grid(axis='y',alpha=.2)
fig.text(.5,.015,'Đo bằng handoff --emit-segments; chưa gồm thời gian tạo bản dịch ngôn ngữ.',ha='center',fontsize=9,color='#555')
fig.tight_layout(rect=(0,.06,1,1))
out=base/'chart-processing-time.png'
if out.exists():raise SystemExit(f'Refusing overwrite {out}')
fig.savefig(out,dpi=180,bbox_inches='tight');plt.close(fig)

fig,axes=plt.subplots(1,2,figsize=(12.0,5.2),sharey=True)
fig.patch.set_facecolor('white')
colors=['#5c9d81','#14452F','#317a9e']
for ax,values,title in [(axes[0],coverage,'Độ phủ dịch trên trang mẫu'),(axes[1],ink_match,'Nét hình giữ nguyên')]:
    bars=ax.barh(labels,values,color=colors,height=.55)
    ax.set_xlim(0,112);ax.set_title(title,fontsize=13,fontweight='bold',pad=14)
    ax.set_xlabel('%')
    ax.grid(axis='x',alpha=.2);ax.set_axisbelow(True)
    for bar,value in zip(bars,values):ax.text(value+1,bar.get_y()+bar.get_height()/2,f'{value:.1f}%',va='center',fontweight='bold')
axes[0].invert_yaxis()
fig.suptitle('Kiểm tra chất lượng trên 3 trang đại diện',fontsize=16,fontweight='bold')
fig.text(.5,.035,'Độ phủ = đoạn đã cung cấp bản dịch/đoạn phát hiện; nét hình = pixel có mực trùng ảnh gốc trong vùng biểu đồ/sơ đồ.',ha='center',fontsize=9,color='#555')
fig.text(.5,.012,'Đây không phải điểm chính xác ngữ nghĩa của bản dịch. Google trả HTTP 429 trong lần thử.',ha='center',fontsize=9,color='#8b3d2c')
fig.tight_layout(rect=(0,.09,1,.92))
out2=base/'chart-sample-quality.png'
if out2.exists():raise SystemExit(f'Refusing overwrite {out2}')
fig.savefig(out2,dpi=180,bbox_inches='tight');plt.close(fig)
summary={'papers':[{'slug':slug,'pages':page,'full_pdf_analysis_seconds':round(full_time,3),'sample_rebuild_seconds_excluding_manual_translation':round(sample_time,3),'sample_translation_coverage_percent':round(cov,1),'figure_ink_pixel_match_percent':round(ink,3)} for slug,page,full_time,sample_time,cov,ink in zip(slugs,pages,full_times,sample_times,coverage,ink_match)]}
path=base/'benchmark-summary.json'
if path.exists():raise SystemExit(f'Refusing overwrite {path}')
path.write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(summary,ensure_ascii=False,indent=2))
print(out.resolve(),out2.resolve())
