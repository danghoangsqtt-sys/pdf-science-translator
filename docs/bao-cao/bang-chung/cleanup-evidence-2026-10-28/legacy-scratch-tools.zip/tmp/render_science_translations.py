﻿from pathlib import Path
import fitz
b=Path('output/electron-science-benchmark-2026-10-01')
items=[('short-quantum-position-momentum',2),('medium-neutron-stars',9),('long-pinn-error-certification',4)]
for slug,page in items:
    src=b/f'{slug}.pdf';dst=b/f'{slug}-vi.pdf'
    with fitz.open(src) as source,fitz.open(dst) as target:
        assert source.page_count==target.page_count
        assert all(a.rect==c.rect for a,c in zip(source,target))
        out=b/f'{slug}-translated-p{page}.png'
        if out.exists():raise SystemExit(f'Refusing overwrite {out}')
        target[page-1].get_pixmap(matrix=fitz.Matrix(1.5,1.5),alpha=False).save(out)
        print(slug,'pages',source.page_count,'target_text_chars',len(target[page-1].get_text()),'render',out.name)
