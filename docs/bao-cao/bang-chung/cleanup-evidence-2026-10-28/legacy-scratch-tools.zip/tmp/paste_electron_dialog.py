﻿import ctypes,time
from ctypes import wintypes
from pathlib import Path
from PIL import ImageGrab
u=ctypes.windll.user32
h=u.FindWindowW(None,'Open')
if not h:raise SystemExit('Open dialog missing')
r=wintypes.RECT();u.GetWindowRect(h,ctypes.byref(r))
print('rect',r.left,r.top,r.right,r.bottom)
u.SetWindowPos(h,-1,0,0,0,0,0x0001|0x0002|0x0040)
u.SetForegroundWindow(h)
time.sleep(.4)
u.SetCursorPos(r.left+350,r.bottom-63)
u.mouse_event(2,0,0,0,0);u.mouse_event(4,0,0,0,0)
time.sleep(.25)
u.keybd_event(0x11,0,0,0);u.keybd_event(0x56,0,0,0);u.keybd_event(0x56,0,2,0);u.keybd_event(0x11,0,2,0)
time.sleep(.8)
p=Path('output/presentation-demo-2026-10-01/electron-dialog-debug.png')
if p.exists():raise SystemExit('Refusing overwrite')
ImageGrab.grab(bbox=(r.left,r.top,r.right,r.bottom),all_screens=True).save(p)
print(p.resolve())
