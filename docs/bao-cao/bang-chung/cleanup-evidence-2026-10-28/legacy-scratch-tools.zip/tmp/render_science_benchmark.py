﻿from pathlib import Path
import fitz
b=Path('output/electron-science-benchmark-2026-10-01')
choices={'short-quantum-position-momentum':[0,1,2], 'medium-neutron-stars':[0,8,9], 'long-pinn-error-certification':[0,3,7]}
for slug,pages in choices.items():
    with fitz.open(b/f'{slug}.pdf') as doc:
        for index in pages:
            out=b/f'{slug}-source-p{index+1}.png'
            if out.exists(): raise SystemExit(f'Refusing overwrite {out}')
            doc[index].get_pixmap(matrix=fitz.Matrix(1.5,1.5),alpha=False).save(out)
            print(out.name)
