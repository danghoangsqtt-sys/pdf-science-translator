﻿import json
from pathlib import Path
base=Path('output/presentation-demo-2026-10-01')
sources=[json.loads(line)['src'] for line in (base/'segments-final.jsonl').read_text(encoding='utf-8').splitlines()]
translations=[
'TOÁN HỌC VÀ VẬT LÝ',
'Tài liệu tiếng Anh ngắn dùng để kiểm thử bản dịch',
'<s1>1. Toán học: đạo hàm</s1>',
'Đạo hàm đo mức độ thay đổi của một đại lượng. Nếu vị trí của một vật là x(t), vận tốc tức thời của nó là đạo hàm của vị trí theo thời gian. Độ dốc của tiếp tuyến cho ta cách hiểu về mặt hình học.',
'<s1>2. Vật lý: chuyển động Newton</s1>',
'Định luật II Newton liên hệ hợp lực tác dụng lên một vật với khối lượng và gia tốc của vật. Khi khối lượng không đổi, lực tăng gấp đôi thì gia tốc cũng tăng gấp đôi. Phương trình này giúp kỹ sư dự đoán chuyển động và thiết kế hệ thống an toàn.',
'Một xe đẩy khối lượng 5 kg chịu hợp lực 10 N sẽ có gia tốc 2 m/s<b2></b2>2.',
'<s1>3. Năng lượng và ứng dụng thực tế</s1>',
'Động năng phụ thuộc vào khối lượng và bình phương vận tốc. Một phương tiện chạy nhanh gấp đôi sẽ có động năng lớn gấp bốn. Mối quan hệ này hữu ích khi ước tính quãng đường phanh và giải thích kết quả đo trong phòng thí nghiệm.',
'<s1>Các đại lượng chính</s1>',
]
assert len(sources)==len(translations)
out=base/'translations-final.jsonl'
if out.exists(): raise SystemExit(f'Refusing to overwrite {out}')
out.write_text(''.join(json.dumps({'src':s,'dst':d},ensure_ascii=False)+'\n' for s,d in zip(sources,translations)),encoding='utf-8')
print(out.resolve())
